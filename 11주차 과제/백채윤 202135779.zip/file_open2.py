#file_open2.py

with open("basic.txt.", "w") as file:
    file.write("Hello Python Programming...!")
