#file_open.py

file = open("basic.txt.", "w")

file.write("Hello Python Programming...!")

file.close()
